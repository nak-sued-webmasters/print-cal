## 0.3.1 (May 17, 2016)

* Fixed support for embedding images on Microsoft Word for Mac 2016

## 0.3.0 (Sep 17, 2015)

* Added support for embedded images. Please see `README.md` for details.

## 0.2.2 (May 21, 2015)

* Corrected publishing as Node.js module (`package.json` now contains correct main entry point)
* Corrected `.npmignore`, so the build artifacts are actually published to npm. Unpublished version
  0.2.1 that was built with incorrect `.npmignore` file.

## 0.2.0 (Apr 23, 2015)

* Added `fullpage` plugin to the sample page to ensure that whole HTML document gets exported
* Added possibility of specyfing document settings, including page orientation
* Added possibility of specyfing page margins

## 0.1.0 (Aug 1, 2014)

* Initial public release
